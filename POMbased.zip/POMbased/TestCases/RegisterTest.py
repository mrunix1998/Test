import time
import sys
import unittest
import HtmlTestRunner
from selenium import webdriver
sys.path.append("/home/mohammad/PycharmProjects/POMbased/")
from PageObjects.RegisterPage import Register


class RegisterTest (unittest.TestCase):

    baseURL = "http://beroozresaan.com/Register"
    firstname = "mohammad"
    lastname = "saemi"
    mobile = "09115914338"
    password = "9115914338ali"
    confirmpass = "9115914338ali"
    referrmobile = "09356037998"

    driver = webdriver.Firefox(executable_path="/home/mohammad/PycharmProjects/POMbased/Drivers/geckodriver")
    driver.implicitly_wait(10)

    @ classmethod
    def setUpClass(cls) :
        cls.driver.get(cls.baseURL)
        cls.driver.maximize_window()

    def test_register(self):
        rp = Register(self.driver)
        rp.setUsername(self.firstname)
        rp.setLastname(self.lastname)
        rp.setPhone(self.mobile)
        rp.setPassword(self.password)
        rp.setConfirm(self.confirmpass)
        rp.setReferrmobile(self.referrmobile)
        rp.clickLogin()
        time.sleep(3)
        if self.driver.find_element_by_xpath("/html/body/div/main/div[2]/div/form/section/div[2]/div[1]"):
            print("_____ Sorry, you have already logged in __________")
        self.assertEqual("ثبت نام - بازار آنلاین به روز رسان-تنوع بی نظیر با قیمت مناسب-فروشگاه اینترنتی بروزرسان", self.driver.title, "title not matching")
    @ classmethod
    def tearDownClass(cls):
        cls.driver.close()

if __name__ == "__main__":
    unittest.main(testRunner= HtmlTestRunner.HTMLTestRunner(output="/home/mohammad/PycharmProjects/POMbased/Reports"))