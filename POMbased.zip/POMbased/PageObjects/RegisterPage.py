class Register :
    # elements :
    textbox_firstname_id = "FirstName"
    textbox_lastname_id = "LastName"
    textbox_phonenumber_id = "Mobile"
    textbox_password_id = "Password"
    textbox_confirmpass_id = "ConfirmPassword"
    textbox_referrmobile_id = "ReferrerMobile"
    link_login_xpath = "/html/body/div/main/div[2]/div/form/section/div[3]/div/button"
    checkbox_button_id = "AcceptTerms"


    def __init__(self, driver):
        self.driver = driver

    def setUsername(self, username):
        self.driver.find_element_by_id(self.textbox_firstname_id).send_keys(username)

    def setLastname(self, lastname):
        self.driver.find_element_by_id(self.textbox_lastname_id).send_keys(lastname)

    def setPhone(self, phonenum):
        self.driver.find_element_by_id(self.textbox_phonenumber_id).send_keys(phonenum)

    def setPassword(self, password):
        self.driver.find_element_by_id(self.textbox_password_id).send_keys(password)

    def setConfirm(self, confirm):
        self.driver.find_element_by_id(self.textbox_confirmpass_id).send_keys(confirm)

    def setReferrmobile(self, referr):
        self.driver.find_element_by_id(self.textbox_referrmobile_id).send_keys(referr)

    def clickLogin(self):
        self.driver.find_element_by_xpath(self.link_login_xpath).click()

    def clickCheckbox(self):
        self.driver.find_element_by_id(self.checkbox_button_id).click()
