from selenium import webdriver


driver = webdriver.Chrome(executable_path="/home/mohammad/PycharmProjects/tests/chromedriver")

driver.get("http://beroozresaan.com/")

driver.save_screenshot("/home/mohammad/Desktop/home.png")

driver.get_screenshot_as_file("/home/mohammad/Desktop/homepage2.png")