from selenium import webdriver
from selenium.webdriver.common.keys import Keys


driver = webdriver.Chrome(executable_path="/home/mohammad/PycharmProjects/tests/chromedriver")

driver.get("http://beroozresaan.com")

driver.find_element_by_xpath("/html/body/header/div/div[1]/div/div[2]/div/div[1]/a/span[1]").click()
driver.find_element_by_xpath("/html/body/header/div/div[1]/div/div[2]/div/div[1]/ul/li[1]/a").click()

user = driver.find_element_by_name("Username")
print(user.is_displayed())
print(user.is_enabled())

paswd = driver.find_element_by_name("Password")
print(paswd.is_displayed())
print(paswd.is_enabled())

user.send_keys("09356037998")
paswd.send_keys("9115914338mohammad")

checkbox = driver.find_element_by_name("RememberMe")
if checkbox.is_selected:
    print(checkbox.is_selected())
    checkbox.click()

driver.find_element_by_css_selector(".btn-success").click()


