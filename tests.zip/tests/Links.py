from selenium import webdriver
from selenium.webdriver.common.by import By

driver = webdriver.Chrome(executable_path="/home/mohammad/PycharmProjects/tests/chromedriver")

driver.get("http://beroozresaan.com/")

# links = driver.find_element(By.TAG_NAME, "a")
# print("Number of links present : ", len(links))
#
# for link in links:
#     print(links.text)

# Clicking on the link
# driver.find_element(By.LINK_TEXT, "بازار ارگانیک و سلامت محور").click()
driver.find_element(By.PARTIAL_LINK_TEXT, "ورود").click()  # find link with part of linkk text
