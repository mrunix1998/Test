from selenium import webdriver
from selenium.webdriver.common.by import By


driver = webdriver.Chrome(executable_path="/home/mohammad/PycharmProjects/tests/chromedriver")

driver.get("http://beroozresaan.com/Register")

# How to find many input boxes present in web page

inputboxes = driver.find_elements(By.CLASS_NAME, "form-control")
print(len(inputboxes))

# How to provide value into text box

driver.find_element(By.ID, "FirstName").send_keys("mohammad")
driver.find_element(By.ID, "LastName").send_keys("salehi")
driver.find_element(By.ID, "Mobile").send_keys("09115914338")
driver.find_element(By.ID, "Password").send_keys("mohammad331")
driver.find_element(By.ID, "ConfirmPassword").send_keys("mohammad331")

# How to get status

# print(driver.find_element(By.ID, "FirstName").is_enabled())
# print(driver.find_element(By.ID, "LastName").is_enabled())
# print(driver.find_element(By.ID, "Mobile").is_enabled())
# print(driver.find_element(By.ID, "Password").is_displayed())
# print(driver.find_element(By.ID, "ConfirmPassword").is_displayed())

