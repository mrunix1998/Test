import XlUtiles
from selenium import webdriver

driver = webdriver.Chrome(executable_path="/home/mohammad/PycharmProjects/tests/chromedriver")

driver.get("http://beroozresaan.com/Login")
driver.maximize_window()

path = "/home/mohammad/Desktop/micro.xlsx"

rows = XlUtiles.getRowCount(path, "Sheet1")

for r in range(2, rows+1):
    username = XlUtiles.readData(path, "Sheet1", r, 1)
    password = XlUtiles.readData(path, "Sheet1", r, 2)

    driver.find_element_by_id("Username").send_keys(username)
    driver.find_element_by_id("Password").send_keys(password)
    driver.find_element_by_xpath("//*[@id='loginform']/form/div[3]/div[1]/button").click()

    if  not driver.current_window_handle:
        print("test is passed")
        XlUtiles.writeData(path, "Sheet1", r, 3, "Test passed")

    else:
        print("test is failed")
        XlUtiles.writeData(path, "Sheet1", r, 3, "Test failed")


    driver.find_element_by_partial_link_text("ورود").click()
    driver.find_element_by_xpath("/html/body/header/div/div[1]/div/div[2]/div/div[1]/ul/li[1]/a").click()