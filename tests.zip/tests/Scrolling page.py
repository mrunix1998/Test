from selenium import webdriver


driver = webdriver.Chrome(executable_path="/home/mohammad/PycharmProjects/tests/chromedriver")

driver.maximize_window()
driver.get("http://beroozresaan.com/")

# 1. Scroll down page by pixel
# driver.execute_script("window.scrollBy(0,1000)","")


# 2. Scroll down till the element is visible
# element = driver.find_element_by_xpath("/html/body/div/div/main/aside/div[10]/section/div/div/div/a/img")
# driver.execute_script("arguments[0].scrollIntoView();", element)

# 3. Scroll down till end
driver.execute_script("window.scrollBy(0, document.body.scrollHeight)")