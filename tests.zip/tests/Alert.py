from selenium import webdriver
import time

driver = webdriver.Chrome(executable_path="/home/mohammad/PycharmProjects/tests/chromedriver")

driver.get("http://testautomationpractice.blogspot.com/")

driver.find_element_by_xpath("//*[@id='HTML9']/div[1]/button").click()

time.sleep(5)

# driver.switch_to_alert().accept()   # Closes alert window using ok button
driver.switch_to_alert().dismiss()   # Closes alert by using cancle button
