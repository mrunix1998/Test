from selenium import webdriver
import time
from selenium.webdriver.chrome.options import Options

chromOptions = Options()

chromOptions.add_experimental_option("prefs", {"download.default_directory": "/home/mohammad/Desktop/"})
driver = webdriver.Chrome(executable_path="/home/mohammad/PycharmProjects/tests/chromedriver", chrome_options=chromOptions)

driver.get("http://demo.automationtesting.in/FileDownload.html")

driver.maximize_window()

# Download text file
driver.find_element_by_id("textbox").send_keys("Hello, my name is mohammad")
driver.find_element_by_id("createTxt").click()
driver.find_element_by_id("link-to-download").click()

# Download PDF file
driver.find_element_by_id("pdfbox").send_keys("Hello, my name is mina")
driver.find_element_by_id("createPdf").click()
driver.find_element_by_id("pdf-link-to-download").click()


# time.sleep(10)
# driver.close()