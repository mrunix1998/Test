from selenium import webdriver
from selenium.webdriver.common.keys import Keys
import time

# Chrome
driver = webdriver.Chrome(executable_path="/home/mohammad/PycharmProjects/tests/chromedriver")

driver.get("http://beroozresaan.com/")

print(driver.title)  # returns the title of the page
print(driver.current_url)  # returns URL of the page

driver.find_element_by_xpath("/html/body/header/div/div[1]/div/div[2]/div/div[2]/div[1]/a/span[1]").click()
time.sleep(5)

# driver.close()  # close focused tab

driver.quit()  # close all tabs
