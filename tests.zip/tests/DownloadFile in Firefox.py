from selenium import webdriver
from selenium.webdriver.firefox.options import Options

fp = webdriver.FirefoxProfile()
fp.set_preference("browser.helperApps.neverAsk.saveToDisk", "text/plain, application/pdf")   # Mine type
fp.set_preference("browser.download.manager.showWhenStarting", False)
fp.set_preference("browser.download.dir", "/home/mohammad/Desktop/ ")
fp.set_preference("browser.download.folderList", 2)
fp.set_preference("pdfjs.disabled", True)


driver = webdriver.Firefox(executable_path="/home/mohammad/PycharmProjects/tests/geckodriver", firefox_profile=fp)

driver.get("http://demo.automationtesting.in/FileDownload.html")

driver.maximize_window()

# Download text file
driver.find_element_by_id("textbox").send_keys("Hello, my name is mohammad")
driver.find_element_by_id("createTxt").click()
driver.find_element_by_id("link-to-download").click()

# Download PDF file
driver.find_element_by_id("pdfbox").send_keys("Hello, my name is mina")
driver.find_element_by_id("createPdf").click()
driver.find_element_by_id("pdf-link-to-download").click()


