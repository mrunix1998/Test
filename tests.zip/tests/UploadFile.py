from selenium import webdriver

driver = webdriver.Chrome(executable_path="/home/mohammad/PycharmProjects/tests/chromedriver")

driver.get("http://testautomationpractice.blogspot.com/")

driver.maximize_window()

driver.switch_to.frame(0)

driver.find_element_by_id("RESULT_FileUpload-10").send_keys("/home/mohammad/Downloads/unnamed.jpg")
