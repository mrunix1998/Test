# assertIsNone  &  assertIsNotNone
import unittest
from selenium import webdriver

class Test (unittest.TestCase):

    def testName(self):
        driver = webdriver.Chrome(executable_path="/home/mohammad/PycharmProjects/tests/chromedriver")
        # driver = None
        # self.assertIsNone(driver)  # check driver have value or not
        self.assertIsNotNone(driver)
if __name__ == "__main__":
    unittest.main()
