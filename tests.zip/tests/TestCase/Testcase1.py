import unittest

class Test(unittest.TestCase):
    def test_FirstTest(self):
        print("This is my first unit test case")

if __name__ == "__main__":
    unittest.main()
