# assertIn  &  assertNotIn
import unittest

class Test(unittest.TestCase):

    def testName(self):
        list = {"python", "selenium", "java"}
        self.assertIn("python", list)   # are the python is in list or not
        self.assertNotIn("Ruby", list)   # are the Ruby is not in list or not

if __name__ == "__main__":
    unittest.main()