# assertTrue & assertFalse
import unittest
from selenium import webdriver

class Apptesting (unittest.TestCase):

    def testName (self):
        driver = webdriver.Chrome(executable_path="/home/mohammad/PycharmProjects/tests/chromedriver")
        driver.get("http://beroozresaan.com/")

        titleOfWebpage = driver.title
        # self.assertTrue(titleOfWebpage == "Google")  # False
        self.assertFalse(titleOfWebpage == "Google")  # True

if __name__ == "__main__":
    unittest.main()