import unittest

class Apptesting (unittest.TestCase):

    @ unittest.SkipTest   # Decorator
    def test_search(self):
        print("This is search test")

    @ unittest.skip("I am skipping this test method because it is not yet ready")
    def test_AdvanedSearch(self):
        print("This is adv search method")

    @ unittest.skipIf(1 == 1, "One is equal to One")
    def test_prepaidRecharge(self):
        print("This is pre-paid recharge")

    def test_postpaidrecharge(self):
        print("This is post-paid recharge")

    def test_loginbymail(self):
        print("This is login by email")

    def test_loginbytwitter(self):
        print("This is login by twitter")

if __name__ == "__main__":
    unittest.main()