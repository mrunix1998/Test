# Relational comparison in assertion :
# assertGreater
# assertGreaterEqual
# assertLess
# assertLessEqual
import unittest

class Test(unittest.TestCase):

    def testName(self):
        # self.assertGreater(100, 20)
        # self.assertGreaterEqual(150, 150)
        # self.assertLess(60, 9)
        self.assertLessEqual(60, 89)

if __name__ == "__main__":
    unittest.main()