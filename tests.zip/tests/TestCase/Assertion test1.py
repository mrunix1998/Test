import unittest
from selenium import webdriver

class Test(unittest.TestCase):

    def testName(self):
        driver = webdriver.Chrome(executable_path="/home/mohammad/PycharmProjects/tests/chromedriver")
        driver.get("http://beroozresaan.com/")
        titleOfWebpage = driver.title
        # assertEqual
        # self.assertEqual("بازار آنلاین به روز رسان-تنوع بی نظیر با قیمت مناسب-فروشگاه اینترنتی بروزرسان", titleOfWebpage, "webpage title is not same")
        self.assertNotEqual("بازار آنلاین به روز رسان-تنوع بی نظیر با قیمت مناسب-فروشگاه اینترنتی بروزرسان", titleOfWebpage, "webpage title is not same")

if __name__ == "__main__":
    unittest.main()