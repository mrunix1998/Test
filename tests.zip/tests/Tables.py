from selenium import webdriver

driver =  webdriver.Chrome(executable_path="/home/mohammad/PycharmProjects/tests/chromedriver")

driver.get("file:///home/mohammad/PycharmProjects/tests/table.html")

rows = len(driver.find_elements_by_xpath("/html/body/table/tbody/tr"))   # count number of rows
columns = len(driver.find_elements_by_xpath("/html/body/table/tbody/tr[1]/th"))   # count number of columns

print("This table has ", rows, "rows and ", columns, "columns .")

print("Company" + "     " + "Contact" + "     " + "Country")
for r in range(2, rows+1):
    for c in range(1, columns+1):
        value = driver.find_element_by_xpath("/html/body/table/tbody/tr["+str(r)+"]/td["+str(c)+"]").text
        print(value, end="    ")
    print()