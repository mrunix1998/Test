from selenium import webdriver
from selenium.webdriver.common.keys import Keys

driver = webdriver.Chrome(executable_path="/home/mohammad/PycharmProjects/tests/chromedriver")

driver.get("http://beroozresaan.com/")

driver.implicitly_wait(10)

# assert "Wellcom in beroozresaan " in driver.title

driver.find_element_by_xpath("/html/body/header/div/div[1]/div/div[2]/div/div[1]/a/span[1]").click()
driver.find_element_by_xpath("/html/body/header/div/div[1]/div/div[2]/div/div[1]/ul/li[1]/a").click()

driver.find_element_by_name("Username").send_keys("09356037998")
driver.find_element_by_name("Password").send_keys("9115914338mohammad")


driver.find_element_by_css_selector(".btn-success").click()

