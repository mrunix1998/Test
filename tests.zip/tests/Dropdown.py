from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import Select

driver = webdriver.Chrome(executable_path="/home/mohammad/PycharmProjects/tests/chromedriver")

driver.get("https://www.expedia.com/")

driver.find_element_by_xpath("//*[@id='tab-car-tab-hp']/span[1]").click()

element = driver.find_element(By.ID, "car-pickup-time-hp-car")
drop = Select(element)

# Select by visible text
drop.select_by_visible_text('1:15 am')


pick = driver.find_element(By.ID, "car-dropoff-time-hp-car")
drop2 = Select(pick)

# Select by index
# drop2.select_by_index(6)


# Select by value
# drop2.select_by_value("0645AM")

# Count all the options
print(len(drop.options))

# Capture all the options and print then as output
all_options = drop.options

for option in all_options:
    print(option.text)
