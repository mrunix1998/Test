from selenium import webdriver
from selenium.webdriver.common.by import By

driver = webdriver.Chrome(executable_path="/home/mohammad/PycharmProjects/tests/chromedriver")

driver.get("http://beroozresaan.com/Register")

# Radio button

# driver.get("http://beroozresaan.com/Register")
#
# status = driver.find_element_by_id("id").is_selected()
# print(status)
#
# driver.find_element_by_id("id").click()
#
# status = driver.find_element_by_id("id").is_selected()
# print(status)

# Checkbox

driver.find_element_by_id("AcceptTerms").click()