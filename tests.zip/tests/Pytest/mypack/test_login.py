import pytest

@ pytest.yield_fixture()
def setUp ():
    print("Opening URL to Login")
    yield
    print("Closing browser after Login")


def test_login_by_mail(setUp):
    print("This is Login by email test")


def test_login_by_facebook(setUp):
    print("This is Login by facebook test")