import pytest

@ pytest.yield_fixture()
def setUp ():
    print("Opening URL to Signup")
    yield
    print("Closing browser Signup")


def test_signup_by_mail(setUp):
    print("This is Signup by email test")


def test_signup_by_facebook(setUp):
    print("This is Signup by facebook test")


# Run test with 3 ways :
# pytest -vs full_path
# pytest -vs file_name
# pytest -vs file_name::method_name