from selenium import webdriver
import pytest

class Test():

    @ pytest.fixture()
    def setup(self):
        self.driver = webdriver.Chrome(executable_path="/home/mohammad/PycharmProjects/tests/chromedriver")
        self.driver.maximize_window()
        yield
        self.driver.close()

    def test_homepage_title(self, setup):
        self.driver.get("http://beroozresaan.com/")
        assert self.driver.title == "بازار آنلاین به روز رسان-تنوع بی نظیر با قیمت مناسب-فروشگاه اینترنتی بروزرسان"

    def test_login(self, setup):
        self.driver.get("http://beroozresaan.com/Login")
        self.driver.find_element_by_id("Username").send_keys("09356037998")
        self.driver.find_element_by_id("Password").send_keys("9115914338mohammad")
        self.driver.find_element_by_xpath("//*[@id='loginform']/form/div[3]/div[1]/button/i").click()
        assert self.driver.title == "بازار آنلاین به روز رسان-تنوع بی نظیر با قیمت مناسب-فروشگاه اینترنتی بروزرسان"


# To Generat the report :
# pytest -vs --html=report.html --self-contained-html filename.py
