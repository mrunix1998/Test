import pytest


# @pytest.fixture()   # like setup method in unittest
# def setup():
#     print("Once before every method")

@pytest.yield_fixture()
def setup():
    print(" ------- Once Before every method --------")
    yield
    print("------- Once After every method ---------")

def testmethod(setup):
    print("this is test method ")


def testmethod2(setup):
    print("this is test method2")