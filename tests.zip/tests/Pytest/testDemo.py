import pytest


def test_method1():
    print("This is test Method1")


def test_method2():
    print("This is test Method2")
