from selenium import webdriver
from selenium.webdriver.common.keys import Keys

# driver = webdriver.Chrome(executable_path="/home/mohammad/PycharmProjects/tests/chromedriver")

driver = webdriver.Firefox(executable_path="/home/mohammad/PycharmProjects/tests/geckodriver")

driver.get("https://beroozresaan.com/")

print(driver.title)  # Title of the page

driver.close()  # close the browser
