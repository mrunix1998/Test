from selenium import webdriver
from selenium.webdriver import ActionChains

driver = webdriver.Chrome(executable_path="/home/mohammad/PycharmProjects/tests/chromedriver")

driver.get("http://beroozresaan.com/")

driver.find_element_by_xpath("/html/body/header/div/div[1]/div/div[2]/div/div[1]/a/span[1]").click()
driver.find_element_by_xpath("/html/body/header/div/div[1]/div/div[2]/div/div[1]/ul/li[1]/a").click()

driver.find_element_by_name("Username").send_keys("09356037998")
driver.find_element_by_name("Password").send_keys("9115914338mohammad")
driver.find_element_by_xpath("//*[@id='loginform']/form/div[3]/div[1]/button").click()

agil = driver.find_element_by_xpath("//*[@id='navbar-main-collapse']/ul/li[8]/a")
fandogh = driver.find_element_by_xpath("/html/body/header/div/nav/div/div[2]/ul/li[8]/div/div/div/div[1]/ul/li[6]/a")

action = ActionChains(driver)
action.move_to_element(agil).move_to_element(fandogh).click().perform()