from selenium import  webdriver

driver = webdriver.Chrome(executable_path="/home/mohammad/PycharmProjects/tests/chromedriver")

driver.get("https://routaa.com/")

driver.find_element_by_xpath("//*[@id='downloadWrapper']/div/div[3]/a").click()

print(driver.current_window_handle)

handels = driver.window_handles   # returns all the handle values of opened browser windows

for handel in handels:
    driver.switch_to.window(handel)
    print(driver.title)
    if driver.title == "روتا - نقشه و مسیریاب فارسی":
        driver.close()   # Close the parent window

driver.quit()
