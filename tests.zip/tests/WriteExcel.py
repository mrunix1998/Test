import openpyxl

path = "/home/mohammad/Desktop/micro.xlsx"

workbook = openpyxl.load_workbook(path)
sheet = workbook.active

for r in range(1, 13):
    for c in range(1, 40):
        sheet.cell(row=r, column=c).value = "wellcome"

workbook.save(path)