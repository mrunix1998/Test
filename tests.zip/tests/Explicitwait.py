from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
import time
from selenium.webdriver.support import expected_conditions as EC

driver = webdriver.Chrome(executable_path="/home/mohammad/PycharmProjects/tests/chromedriver")

driver.implicitly_wait(5)
driver.maximize_window()

driver.get("http://www.expedia.com/")

driver.find_element(By.ID, "tab-flight-tab-hp").click()
time.sleep(2)
driver.find_element(By.ID, "flight-origin-hp-flight").send_keys("SFO")
driver.find_element(By.ID, "flight-destination-hp-flight").send_keys("NYC")

driver.find_element(By.ID, "flight-departing-hp-flight").clear()
driver.find_element(By.ID, "flight-departing-hp-flight").send_keys("04/15/2020")
driver.find_element(By.ID, "flight-returning-hp-flight").clear()
driver.find_element(By.ID, "flight-returning-hp-flight").send_keys("04/21/2020")

driver.find_element_by_css_selector(".wizard-tabs .search-btn-col .btn-primary").click()

# Explicit waits
wait = WebDriverWait(driver, 100)
element = wait.until(EC.element_to_be_clickable((By.XPATH, "//*[@id='stopFilter_stops-0']")))
element.click()

time.sleep(5)
driver.quit()
