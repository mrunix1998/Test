from selenium import webdriver
from selenium.webdriver.common.keys import Keys
import time

# go to next url in one tab and back to another url in same tab

driver = webdriver.Chrome(executable_path="/home/mohammad/PycharmProjects/tests/chromedriver")

driver.get("http://beroozresaan.com")
print(driver.title)  # FT

driver.get("https://routaa.com/")
time.sleep(5)
print(driver.title) # TT

driver.back()
time.sleep(5)
print(driver.title)  #FT

driver.forward()
time.sleep(5)
print(driver.title)  #TT

driver.quit()