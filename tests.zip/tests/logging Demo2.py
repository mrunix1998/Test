import logging

logging.basicConfig(filename="/TestCase/test2.log",
                    format="%(asctime)s: %(levelname)s: %(message)s",
                    datefmt='%d/%m/%Y %I:%M:%S %p'
                    )   # Create log file

logger = logging.getLogger()
logger.setLevel(logging.DEBUG)

logger.debug("This is debug message")
logger.info("This is info message")
logger.warning("This is  message")
logger.error("This is error message")
logger.critical("This is critical message")