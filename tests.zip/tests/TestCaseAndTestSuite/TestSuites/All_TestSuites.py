import unittest
from package1.TC_logintest import LoginTest
from package1.TC_signupTest import SignupTest

from package2.TC_paymentreturnsbankTest import PaymentReturnsTest
from package2.paymentTest import PaymentTest

tc1 = unittest.TestLoader().loadTestsFromTestCase(LoginTest)
tc2 = unittest.TestLoader().loadTestsFromTestCase(SignupTest)
tc3 = unittest.TestLoader().loadTestsFromTestCase(PaymentReturnsTest)
tc4 = unittest.TestLoader().loadTestsFromTestCase(PaymentTest)

# Creating test suites
sanityTestSuite = unittest.TestSuite([tc1, tc2])  # Sanity test suite
functionalTestSuite = unittest.TestSuite([tc3, tc4])  # functional test suite
masterTestSuite = unittest.TestSuite([tc1, tc2, tc3, tc4])  # master test suite

unittest.TextTestRunner(verbosity=2).run(masterTestSuite)
# unittest.TextTestRunner().run(sanityTestSuite)
# unittest.TextTestRunner().run(functionalTestSuite)