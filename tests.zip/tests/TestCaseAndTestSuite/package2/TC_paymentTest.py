import unittest

class PaymentTest(unittest.TestCase):

    def test_PaymentinDollar(self):
        print("This is payment in dollar test")
        self.assertTrue(True)

    def test_paymentinToman(self):
        print("This is payment in toman test")
        self.assertTrue(True)

if __name__ == "__main__":
    unittest.main()